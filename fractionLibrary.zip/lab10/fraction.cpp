#include <iostream>
#include <cmath>
using namespace std;


class Fraction {
    private:
    double numerator, denominator;

    int gcd(int a, int b) {
    a = abs(a);
    b = abs(b);
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}


    public:
    Fraction(double n, double d) : numerator(n), denominator(d) {

        if (d == 0) {
            cout << "Error. Division by zero not allowed" << endl;
            d = 1;
        }

        if (denominator < 0) {
    numerator = -numerator;
    denominator = -denominator;
}

int divisor = gcd(static_cast<int>(numerator), static_cast<int>(denominator));
if (divisor != 0) {
    numerator /= divisor;
    denominator /= divisor;
}
    }

Fraction operator+(const Fraction& other) const {
   double newN = ((other.denominator * numerator) + (denominator * other.numerator));
    double newD = (denominator * other.denominator);

    return Fraction(newN, newD);
}

Fraction operator-(const Fraction& other) const {
   double newN = ((other.denominator * numerator) - (denominator * other.numerator));
    double newD = (denominator * other.denominator);

    return Fraction(newN, newD);
}

Fraction operator*(const Fraction& other) const {
   double newN = (numerator * other.numerator);
    double newD = (denominator * other.denominator);

    return Fraction(newN, newD);
}

Fraction operator/(const Fraction& other) const {
   double newN = (numerator * other.denominator);
    double newD = (denominator * other.numerator);

    return Fraction(newN, newD);
}

bool operator==(const Fraction& other) const {
    return (numerator == other.numerator) && (denominator == other.denominator);
}

bool operator!=(const Fraction& other) const {
    return (numerator != other.numerator) || (denominator != other.denominator);
}

bool operator<(const Fraction& other) const {
    return (numerator * other.denominator) < (denominator * other.numerator);
}

bool operator>(const Fraction& other) const {
    return (numerator * other.denominator) > (denominator * other.numerator);
}

Fraction operator=(const Fraction& other) {
    if (this != &other) {
        numerator = other.numerator;
        denominator = other.denominator;
    }
    return *this;
}

Fraction& operator+=(const Fraction& other) {
    double newN = (numerator * other.denominator) + (denominator * other.numerator);
    double newD = (denominator * other.denominator);

    numerator = newN;
    denominator = newD;

    return *this;
}

Fraction& operator-=(const Fraction& other) {
    double newN = (numerator * other.denominator) - (denominator * other.numerator);
    double newD = (denominator * other.denominator);

    numerator = newN;
    denominator = newD;

    return *this;
}

Fraction operator-() const {
    return Fraction(-numerator, denominator);
}

friend ostream& operator<<(ostream& os, const Fraction& f);
friend istream& operator>>(istream& is, Fraction& f);


};

ostream& operator<<(ostream& os, const Fraction& f) {
    os << f.numerator << '/' << f.denominator;
     return os;
}


istream& operator>>(istream& is, Fraction& f) {
    char slash = '/';
    is >> f.numerator >> slash >> f.denominator;
    return is;
}